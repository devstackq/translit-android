package kz.kaspi.translit.models


data class YandexDataAdapter(
    var input:String? = null,
    var result: String? = null
)