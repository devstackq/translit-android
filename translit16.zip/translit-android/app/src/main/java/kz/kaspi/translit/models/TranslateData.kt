package kz.kaspi.translit.models

data class TranslateData (
    var inputValue: String? = null,
    var resultValue: String? = null

)