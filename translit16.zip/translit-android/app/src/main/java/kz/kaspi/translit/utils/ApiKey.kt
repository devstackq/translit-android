package kz.kaspi.translit.utils


class YandexApi {
    companion object {
        val BASE_URL = "https://translate.yandex.net/"
        val KEY = "trnsl.1.1.20200526T183646Z.6a1f5538f7fbd1e4.e52a43209fb44b2f31f2d11b5ad308cf02a4bc32"
    }
}