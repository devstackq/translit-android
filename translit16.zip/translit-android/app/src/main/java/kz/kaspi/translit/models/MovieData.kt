package kz.kaspi.translit.models

//class MoviesData (val movieTitle: String, val movieURL: String): Serializable {}
data class MoviesData(
    var movieTitle: String,
    var movieURL: String
)